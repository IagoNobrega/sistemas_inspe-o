from flask import Blueprint, request, jsonify, render_template, url_for, redirect, flash, current_app
import os
import cv2
import numpy as np
import json
import uuid
import time
import logging
import traceback
from werkzeug.utils import secure_filename
from src.models.product import db, Product, ReferenceImage, Inspection

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

inspection_bp = Blueprint('inspection', __name__, url_prefix='/inspection')

# Configurações para upload de arquivos
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'images', 'uploads')
RESULTS_FOLDER = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'images', 'results')

# Criar diretórios se não existirem
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULTS_FOLDER, exist_ok=True)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@inspection_bp.route('/')
def inspect_form():
    """Exibe formulário para inspeção de produto"""
    try:
        # Obter todos os produtos ativos
        products = Product.query.filter_by(active=True).all()
        
        # Verificar se há um produto selecionado
        selected_product_id = request.args.get('product_id', type=int)
        selected_product = None
        
        if selected_product_id:
            selected_product = Product.query.get(selected_product_id)
            if not selected_product:
                flash(f'Produto com ID {selected_product_id} não encontrado', 'error')
        
        return render_template(
            'inspection/inspect.html',
            products=products,
            selected_product=selected_product,
            selected_product_id=selected_product_id
        )
    except Exception as e:
        logger.error(f"Erro ao carregar formulário de inspeção: {str(e)}")
        logger.error(traceback.format_exc())
        flash(f'Erro ao carregar página: {str(e)}', 'error')
        return redirect(url_for('products.index'))

@inspection_bp.route('/analyze', methods=['POST'])
def analyze():
    """Analisa uma imagem de produto"""
    try:
        logger.info("Iniciando análise de imagem")
        
        if 'image' not in request.files:
            logger.warning("Nenhuma imagem enviada na requisição")
            return jsonify({'error': 'Nenhuma imagem enviada'}), 400
        
        file = request.files['image']
        product_id = request.form.get('product_id', type=int)
        
        logger.info(f"Analisando imagem para produto ID: {product_id}")
        
        if not product_id:
            logger.warning("ID do produto não especificado")
            return jsonify({'error': 'Produto não especificado'}), 400
        
        product = Product.query.get(product_id)
        if not product:
            logger.warning(f"Produto com ID {product_id} não encontrado")
            return jsonify({'error': f'Produto com ID {product_id} não encontrado'}), 404
        
        # Verificar se o produto tem imagem de referência
        primary_image = None
        for img in product.reference_images:
            if img.is_primary:
                primary_image = img
                break
        
        if not primary_image:
            logger.warning(f"Produto {product.name} (ID: {product_id}) não possui imagem de referência")
            return jsonify({'error': 'Produto não possui imagem de referência'}), 400
        
        if file.filename == '':
            logger.warning("Nome do arquivo vazio")
            return jsonify({'error': 'Nenhum arquivo selecionado'}), 400
        
        if not allowed_file(file.filename):
            logger.warning(f"Tipo de arquivo não permitido: {file.filename}")
            return jsonify({'error': 'Tipo de arquivo não permitido. Use apenas JPG, PNG ou GIF'}), 400
        
        # Gerar nome único para o arquivo
        filename = str(uuid.uuid4()) + '.' + file.filename.rsplit('.', 1)[1].lower()
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        
        logger.info(f"Salvando arquivo em: {filepath}")
        file.save(filepath)
        
        # Verificar se o arquivo foi salvo corretamente
        if not os.path.exists(filepath):
            logger.error(f"Falha ao salvar arquivo em {filepath}")
            return jsonify({'error': 'Falha ao salvar arquivo'}), 500
        
        # Processar a imagem
        reference_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', primary_image.path)
        
        if not os.path.exists(reference_path):
            logger.error(f"Imagem de referência não encontrada: {reference_path}")
            return jsonify({'error': 'Imagem de referência não encontrada'}), 500
        
        logger.info(f"Processando imagem com referência: {reference_path}")
        result = process_image(filepath, reference_path)
        
        if not result:
            logger.error("Falha no processamento da imagem")
            return jsonify({'error': 'Falha no processamento da imagem'}), 500
        
        # Salvar resultado da inspeção no banco de dados
        try:
            inspection = Inspection(
                product_id=product_id,
                image_path=f"images/uploads/{filename}",
                result_image_path=result['defect_image'].replace('/static/', ''),
                approved=result['approved'],
                defects_count=len(result['defects']),
                defects_details=json.dumps(result['defects'])
            )
            
            db.session.add(inspection)
            db.session.commit()
            logger.info(f"Inspeção salva com sucesso. ID: {inspection.id}")
        except Exception as e:
            db.session.rollback()
            logger.error(f"Erro ao salvar inspeção no banco de dados: {str(e)}")
            logger.error(traceback.format_exc())
            # Continuar mesmo com erro no banco de dados, apenas logar
        
        logger.info(f"Análise concluída. Resultado: {'APROVADO' if result['approved'] else 'REPROVADO'}")
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"Erro durante análise de imagem: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@inspection_bp.route('/history')
def history():
    """Exibe histórico de inspeções"""
    try:
        # Parâmetros de filtro
        product_id = request.args.get('product_id', type=int)
        status = request.args.get('status', '')
        date_from = request.args.get('date_from', '')
        date_to = request.args.get('date_to', '')
        
        # Consulta base
        query = Inspection.query
        
        # Aplicar filtros
        if product_id:
            query = query.filter_by(product_id=product_id)
        
        if status == 'approved':
            query = query.filter_by(approved=True)
        elif status == 'rejected':
            query = query.filter_by(approved=False)
        
        # Filtros de data
        # (implementação omitida para simplificar)
        
        # Ordenar por data, mais recente primeiro
        query = query.order_by(Inspection.created_at.desc())
        
        inspections = query.all()
        products = Product.query.all()
        
        return render_template(
            'inspection/history.html',
            inspections=inspections,
            products=products,
            selected_product_id=product_id,
            status=status,
            date_from=date_from,
            date_to=date_to
        )
    except Exception as e:
        logger.error(f"Erro ao carregar histórico: {str(e)}")
        logger.error(traceback.format_exc())
        flash(f'Erro ao carregar histórico: {str(e)}', 'error')
        return redirect(url_for('products.index'))

@inspection_bp.route('/<int:id>')
def show(id):
    """Exibe detalhes de uma inspeção específica"""
    try:
        inspection = Inspection.query.get_or_404(id)
        
        # Converter defects_details de JSON para lista
        defects = []
        if inspection.defects_details:
            try:
                defects = json.loads(inspection.defects_details)
            except json.JSONDecodeError:
                logger.warning(f"Erro ao decodificar JSON de defeitos para inspeção {id}")
        
        return render_template(
            'inspection/show.html',
            inspection=inspection,
            defects=defects
        )
    except Exception as e:
        logger.error(f"Erro ao mostrar detalhes da inspeção {id}: {str(e)}")
        logger.error(traceback.format_exc())
        flash(f'Erro ao carregar detalhes: {str(e)}', 'error')
        return redirect(url_for('inspection.history'))

def normalize_image(image):
    """
    Normaliza a imagem para reduzir variações de iluminação
    """
    try:
        # Verificar se a imagem é válida
        if image is None or image.size == 0:
            logger.error("Imagem inválida para normalização")
            return None
            
        # Converter para LAB para separar luminância (L) das cores (A,B)
        lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        
        # Aplicar CLAHE (Contrast Limited Adaptive Histogram Equalization) no canal L
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        cl = clahe.apply(l)
        
        # Mesclar canais normalizados
        merged = cv2.merge([cl, a, b])
        
        # Converter de volta para BGR
        normalized = cv2.cvtColor(merged, cv2.COLOR_LAB2BGR)
        
        return normalized
    except Exception as e:
        logger.error(f"Erro na normalização da imagem: {str(e)}")
        logger.error(traceback.format_exc())
        return image  # Retorna a imagem original em caso de erro

def detect_leds(image):
    """
    Detecta e segmenta os LEDs na imagem usando múltiplos métodos
    para maior robustez
    """
    try:
        # Verificar se a imagem é válida
        if image is None or image.size == 0:
            logger.error("Imagem inválida para detecção de LEDs")
            return None
        
        # Converter para HSV para melhor segmentação de cor
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        
        # Definir múltiplas faixas de cor para LEDs amarelos/brancos
        # Faixa para LEDs amarelos
        lower_yellow = np.array([15, 70, 100])
        upper_yellow = np.array([45, 255, 255])
        
        # Faixa para LEDs brancos/brilhantes
        lower_white = np.array([0, 0, 180])
        upper_white = np.array([180, 30, 255])
        
        # Criar máscaras para cada faixa de cor
        mask_yellow = cv2.inRange(hsv, lower_yellow, upper_yellow)
        mask_white = cv2.inRange(hsv, lower_white, upper_white)
        
        # Combinar as máscaras
        mask = cv2.bitwise_or(mask_yellow, mask_white)
        
        # Aplicar operações morfológicas para limpar a máscara
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        
        # Método adicional: detecção baseada em brilho
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        _, bright_mask = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY)
        
        # Combinar com a máscara baseada em cor
        mask = cv2.bitwise_or(mask, bright_mask)
        
        # Limpar novamente
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        
        return mask
    except Exception as e:
        logger.error(f"Erro na detecção de LEDs: {str(e)}")
        logger.error(traceback.format_exc())
        return None

def compare_led_patterns(ref_image, test_image):
    """
    Compara padrões de LEDs entre imagem de referência e imagem de teste
    usando técnicas de correspondência de padrões
    """
    try:
        # Converter para escala de cinza
        ref_gray = cv2.cvtColor(ref_image, cv2.COLOR_BGR2GRAY)
        test_gray = cv2.cvtColor(test_image, cv2.COLOR_BGR2GRAY)
        
        # Aplicar threshold para destacar os LEDs
        _, ref_thresh = cv2.threshold(ref_gray, 200, 255, cv2.THRESH_BINARY)
        _, test_thresh = cv2.threshold(test_gray, 200, 255, cv2.THRESH_BINARY)
        
        # Encontrar contornos dos LEDs na imagem de referência
        ref_contours, _ = cv2.findContours(ref_thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Filtrar contornos pequenos
        ref_contours = [c for c in ref_contours if cv2.contourArea(c) > 50]
        
        # Criar máscara para cada LED na imagem de referência
        defects = []
        defect_image = test_image.copy()
        
        # Para cada LED na referência, verificar se existe na imagem de teste
        for i, contour in enumerate(ref_contours):
            # Obter região de interesse (ROI) do LED
            x, y, w, h = cv2.boundingRect(contour)
            
            # Expandir um pouco a ROI para garantir que todo o LED seja capturado
            x_expanded = max(0, x - 5)
            y_expanded = max(0, y - 5)
            w_expanded = min(ref_thresh.shape[1] - x_expanded, w + 10)
            h_expanded = min(ref_thresh.shape[0] - y_expanded, h + 10)
            
            # Extrair ROI da imagem de referência
            ref_roi = ref_thresh[y_expanded:y_expanded+h_expanded, x_expanded:x_expanded+w_expanded]
            
            # Extrair ROI correspondente da imagem de teste
            test_roi = test_thresh[y_expanded:y_expanded+h_expanded, x_expanded:x_expanded+w_expanded]
            
            # Calcular diferença entre as ROIs
            diff_roi = cv2.absdiff(ref_roi, test_roi)
            
            # Calcular porcentagem de diferença
            diff_percentage = (cv2.countNonZero(diff_roi) / (w_expanded * h_expanded)) * 100
            
            # Se a diferença for significativa, considerar como defeito
            if diff_percentage > 30:  # Ajustar este limiar conforme necessário
                defects.append(f"Defeito #{len(defects)+1}: LED com anomalia na posição ({x}, {y})")
                cv2.rectangle(defect_image, (x_expanded, y_expanded), 
                             (x_expanded + w_expanded, y_expanded + h_expanded), (0, 0, 255), 2)
        
        return defects, defect_image
    except Exception as e:
        logger.error(f"Erro na comparação de padrões de LEDs: {str(e)}")
        logger.error(traceback.format_exc())
        return [], test_image

def process_image(image_path, reference_path):
    """
    Processa a imagem para detectar defeitos comparando com a referência
    Versão completamente reestruturada para maior precisão e robustez
    """
    try:
        logger.info(f"Iniciando processamento de imagem: {image_path}")
        logger.info(f"Usando referência: {reference_path}")
        
        # Carregar imagens
        test_image = cv2.imread(image_path)
        reference_image = cv2.imread(reference_path)
        
        # Verificar se as imagens foram carregadas corretamente
        if test_image is None:
            logger.error(f"Falha ao carregar imagem de teste: {image_path}")
            return None
            
        if reference_image is None:
            logger.error(f"Falha ao carregar imagem de referência: {reference_path}")
            return None
        
        logger.info(f"Imagens carregadas. Teste: {test_image.shape}, Referência: {reference_image.shape}")
        
        # Redimensionar imagem de teste para corresponder à referência
        test_image = cv2.resize(test_image, (reference_image.shape[1], reference_image.shape[0]))
        logger.info(f"Imagem de teste redimensionada para: {test_image.shape}")
        
        # Normalizar iluminação em ambas as imagens
        logger.info("Normalizando iluminação das imagens")
        test_norm = normalize_image(test_image)
        ref_norm = normalize_image(reference_image)
        
        if test_norm is None or ref_norm is None:
            logger.error("Falha na normalização das imagens")
            return {
                'approved': False,
                'defects': ["Erro ao processar imagens: falha na normalização"],
                'analyzed_image': url_for('static', filename=f"images/uploads/{os.path.basename(image_path)}"),
                'defect_image': url_for('static', filename=f"images/uploads/{os.path.basename(image_path)}")
            }
        
        # MÉTODO 1: Comparação direta de padrões de LEDs
        logger.info("Aplicando método 1: Comparação direta de padrões de LEDs")
        defects1, defect_image1 = compare_led_patterns(ref_norm, test_norm)
        logger.info(f"Método 1 encontrou {len(defects1)} defeitos")
        
        # MÉTODO 2: Detecção baseada em diferenças de segmentação
        logger.info("Aplicando método 2: Detecção baseada em diferenças de segmentação")
        
        # Detectar LEDs em ambas as imagens
        test_leds = detect_leds(test_norm)
        ref_leds = detect_leds(ref_norm)
        
        if test_leds is None or ref_leds is None:
            logger.error("Falha na detecção de LEDs")
            # Continuar com os resultados do método 1
            defects2 = []
            defect_image2 = test_image.copy()
        else:
            # Encontrar diferenças significativas entre os LEDs
            diff = cv2.absdiff(ref_leds, test_leds)
            
            # Aplicar threshold para destacar apenas diferenças significativas
            _, diff_thresh = cv2.threshold(diff, 50, 255, cv2.THRESH_BINARY)
            
            # Aplicar operações morfológicas para reduzir ruído
            kernel = np.ones((5, 5), np.uint8)
            diff_cleaned = cv2.morphologyEx(diff_thresh, cv2.MORPH_OPEN, kernel)
            
            # Encontrar contornos das diferenças
            contours, _ = cv2.findContours(diff_cleaned, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            logger.info(f"Método 2 encontrou {len(contours)} contornos de diferenças")
            
            # Filtrar contornos por tamanho para identificar LEDs com defeito
            defects2 = []
            defect_image2 = test_image.copy()
            
            # Reduzir o limite mínimo para considerar um defeito
            min_defect_area = 50  # Área mínima reduzida para maior sensibilidade
            
            for i, contour in enumerate(contours):
                area = cv2.contourArea(contour)
                if area > min_defect_area:
                    # Desenhar contorno vermelho ao redor do defeito
                    cv2.drawContours(defect_image2, [contour], -1, (0, 0, 255), 2)
                    
                    # Obter coordenadas do defeito
                    x, y, w, h = cv2.boundingRect(contour)
                    defect_position = f"Posição ({x}, {y})"
                    
                    defects2.append(f"Defeito #{len(defects2)+1}: LED com anomalia na {defect_position}")
                    logger.info(f"Método 2 - Defeito detectado: {defect_position}, Área: {area}")
        
        # MÉTODO 3: Comparação de histogramas de cores
        logger.info("Aplicando método 3: Comparação de histogramas de cores")
        
        # Dividir a imagem em uma grade para análise local
        grid_size = 4  # Dividir em 4x4 = 16 regiões
        h, w = test_norm.shape[:2]
        cell_h, cell_w = h // grid_size, w // grid_size
        
        defects3 = []
        defect_image3 = test_image.copy()
        
        for i in range(grid_size):
            for j in range(grid_size):
                # Definir região da grade
                y1, y2 = i * cell_h, (i + 1) * cell_h
                x1, x2 = j * cell_w, (j + 1) * cell_w
                
                # Extrair região da grade para ambas as imagens
                ref_cell = ref_norm[y1:y2, x1:x2]
                test_cell = test_norm[y1:y2, x1:x2]
                
                # Calcular histogramas para cada canal de cor
                channels = [0, 1, 2]  # B, G, R
                hist_size = [32, 32, 32]
                ranges = [0, 256, 0, 256, 0, 256]
                
                ref_hist = cv2.calcHist([ref_cell], channels, None, hist_size, ranges)
                test_hist = cv2.calcHist([test_cell], channels, None, hist_size, ranges)
                
                # Normalizar histogramas
                cv2.normalize(ref_hist, ref_hist, 0, 1, cv2.NORM_MINMAX)
                cv2.normalize(test_hist, test_hist, 0, 1, cv2.NORM_MINMAX)
                
                # Comparar histogramas
                hist_diff = cv2.compareHist(ref_hist, test_hist, cv2.HISTCMP_CORREL)
                
                # Se a correlação for baixa, considerar como defeito
                if hist_diff < 0.7:  # Ajustar este limiar conforme necessário
                    defects3.append(f"Defeito #{len(defects3)+1}: Anomalia de cor na região ({x1}, {y1})")
                    cv2.rectangle(defect_image3, (x1, y1), (x2, y2), (0, 0, 255), 2)
                    logger.info(f"Método 3 - Defeito detectado na região ({x1}, {y1}), Correlação: {hist_diff}")
        
        logger.info(f"Método 3 encontrou {len(defects3)} defeitos")
        
        # Combinar resultados dos três métodos
        all_defects = defects1 + defects2 + defects3
        
        # Remover duplicatas (defeitos detectados por múltiplos métodos)
        unique_defects = []
        for defect in all_defects:
            if defect not in unique_defects:
                unique_defects.append(defect)
        
        logger.info(f"Total de defeitos únicos detectados: {len(unique_defects)}")
        
        # Combinar imagens de defeitos
        defect_image = test_image.copy()
        
        # Copiar marcações de defeitos de cada método
        for method_img in [defect_image1, defect_image2, defect_image3]:
            # Encontrar diferenças entre a imagem original e a imagem com marcações
            diff = cv2.absdiff(test_image, method_img)
            mask = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
            _, mask = cv2.threshold(mask, 1, 255, cv2.THRESH_BINARY)
            
            # Aplicar as marcações à imagem final
            defect_image = cv2.bitwise_and(defect_image, defect_image, mask=cv2.bitwise_not(mask))
            defect_image = cv2.bitwise_or(defect_image, cv2.bitwise_and(method_img, method_img, mask=mask))
        
        # Determinar se a peça é aprovada ou reprovada
        approved = len(unique_defects) == 0
        logger.info(f"Resultado da análise: {'APROVADO' if approved else 'REPROVADO'}")
        
        # Salvar imagens de resultado
        result_filename = str(uuid.uuid4())
        analyzed_path = os.path.join(RESULTS_FOLDER, f"{result_filename}_analyzed.jpg")
        defect_path = os.path.join(RESULTS_FOLDER, f"{result_filename}_defects.jpg")
        
        cv2.imwrite(analyzed_path, test_image)
        cv2.imwrite(defect_path, defect_image)
        logger.info(f"Imagens de resultado salvas: {analyzed_path}, {defect_path}")
        
        # Construir URLs relativas para as imagens
        analyzed_url = url_for('static', filename=f"images/results/{result_filename}_analyzed.jpg")
        defect_url = url_for('static', filename=f"images/results/{result_filename}_defects.jpg")
        
        # Forçar resultado para APROVADO se a imagem for muito similar à referência
        # Isso é uma medida de segurança para evitar falsos positivos
        if len(unique_defects) <= 2:  # Se houver poucos defeitos, verificar similaridade geral
            # Calcular similaridade estrutural (SSIM)
            gray_ref = cv2.cvtColor(reference_image, cv2.COLOR_BGR2GRAY)
            gray_test = cv2.cvtColor(test_image, cv2.COLOR_BGR2GRAY)
            
            # Calcular MSE (Mean Squared Error)
            mse = np.mean((gray_ref - gray_test) ** 2)
            
            # Se MSE for baixo, as imagens são muito similares
            if mse < 1000:  # Ajustar este limiar conforme necessário
                logger.info(f"MSE muito baixo ({mse}), forçando resultado para APROVADO")
                approved = True
                unique_defects = []
        
        return {
            'approved': approved,
            'defects': unique_defects,
            'analyzed_image': analyzed_url,
            'defect_image': defect_url
        }
    except Exception as e:
        logger.error(f"Erro no processamento de imagem: {str(e)}")
        logger.error(traceback.format_exc())
        
        # Retornar resultado de erro
        return {
            'approved': False,
            'defects': [f"Erro ao processar imagem: {str(e)}"],
            'analyzed_image': url_for('static', filename=f"images/uploads/{os.path.basename(image_path)}") if image_path else "",
            'defect_image': url_for('static', filename=f"images/uploads/{os.path.basename(image_path)}") if image_path else ""
        }
